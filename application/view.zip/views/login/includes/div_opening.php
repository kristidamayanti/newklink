<div class="row-fluid">
  <div class="block span12">
     <div class="block-heading" >
       <i class="<?php echo $icon; ?>" ></i>&nbsp;<?php echo $form_header; ?> 
       
     </div>
     <div class="block-body collapse in">
        <div class="box-content">