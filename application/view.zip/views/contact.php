<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<style type="text/css">.gm-style .gm-style-mtc label,.gm-style .gm-style-mtc div{font-weight:400}</style><style type="text/css">.gm-style .gm-style-cc span,.gm-style .gm-style-cc a,.gm-style .gm-style-mtc div{font-size:10px}</style><link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700"/><style type="text/css">@media print {  .gm-style .gmnoprint, .gmnoprint {    display:none  }}@media screen {  .gm-style .gmnoscreen, .gmnoscreen {    display:none  }}</style><style type="text/css">.gm-style{font-family:Roboto,Arial,sans-serif;font-size:11px;font-weight:400;text-decoration:none}</style>
<style id="holderjs-style" type="text/css"></style><script type="text/javascript" charset="UTF-8" src="http://maps.gstatic.com/cat_js/maps-api-v3/api/js/18/4/%7Bcommon,map,util,geocoder,marker%7D.js" style=""></script><script type="text/javascript" charset="UTF-8" src="http://maps.gstatic.com/cat_js/maps-api-v3/api/js/18/4/%7Bonion%7D.js"></script><script type="text/javascript" charset="UTF-8" src="http://maps.googleapis.com/maps/api/js/AuthenticationService.Authenticate?1shttp%3A%2F%2Fwww.k-link.co.id%2Findex.php%2Fcontact&5e1&callback=_xdc_._s5s83f&token=21509"></script><script type="text/javascript" charset="UTF-8" src="http://maps.googleapis.com/maps/api/js/GeocodeService.Search?4sGedung%20Tower%20K%20-%20Link%2C%20Tower%20K%20-%20Link%2C%20Jalan%20Jenderal%20Gatot%20Subroto%2C%20Kota%20Jakarta%20Selatan%2C%20DKI%20Jakarta&7sUS&9sen-US&callback=_xdc_._20z0m7&token=117063"></script><script type="text/javascript" charset="UTF-8" src="http://maps.googleapis.com/maps/api/js/GeocodeService.Search?4sGedung%20Tower%20K%20-%20Link%2C%20Tower%20K%20-%20Link%2C%20Jalan%20Jenderal%20Gatot%20Subroto%2C%20Kota%20Jakarta%20Selatan%2C%20DKI%20Jakarta&7sUS&9sen-US&callback=_xdc_._20z0m7&token=117063"></script><script type="text/javascript" charset="UTF-8" src="http://maps.gstatic.com/cat_js/maps-api-v3/api/js/18/4/%7Bstats%7D.js"></script><script type="text/javascript" charset="UTF-8" src="http://maps.gstatic.com/cat_js/maps-api-v3/api/js/18/4/%7Bcontrols%7D.js"></script><script type="text/javascript" charset="UTF-8" src="http://mt1.googleapis.com/vt?pb=!1m4!1m3!1i16!2i52213!3i33904!1m4!1m3!1i16!2i52213!3i33905!1m4!1m3!1i16!2i52213!3i33906!1m4!1m3!1i16!2i52214!3i33904!1m4!1m3!1i16!2i52214!3i33905!1m4!1m3!1i16!2i52215!3i33904!1m4!1m3!1i16!2i52215!3i33905!1m4!1m3!1i16!2i52214!3i33906!1m4!1m3!1i16!2i52215!3i33906!1m4!1m3!1i16!2i52216!3i33904!1m4!1m3!1i16!2i52216!3i33905!1m4!1m3!1i16!2i52216!3i33906!2m3!1e0!2sm!3i274000000!3m9!2sen-US!3sUS!5e18!12m1!1e47!12m3!1e37!2m1!1ssmartmaps!4e3!20m1!1b1&callback=_xdc_._eekupa&token=11685"></script><script type="text/javascript" charset="UTF-8" src="http://maps.googleapis.com/maps/api/js/ViewportInfoService.GetViewportInfo?1m6&1m2&1d-6.248205403482547&2d106.80480783718895&2m2&1d-6.221755264535673&2d106.84661612133084&2u16&4sen-US&5e0&6sm%40274000000&7b0&8e0&9b0&10b1&callback=_xdc_._rt8p1w&token=110223"></script><script type="text/javascript" charset="UTF-8" src="http://mt0.googleapis.com/vt?pb=!1m4!1m3!1i16!2i52213!3i33904!1m4!1m3!1i16!2i52213!3i33905!1m4!1m3!1i16!2i52213!3i33906!1m4!1m3!1i16!2i52214!3i33904!1m4!1m3!1i16!2i52214!3i33905!1m4!1m3!1i16!2i52215!3i33904!1m4!1m3!1i16!2i52215!3i33905!1m4!1m3!1i16!2i52214!3i33906!1m4!1m3!1i16!2i52215!3i33906!1m4!1m3!1i16!2i52216!3i33904!1m4!1m3!1i16!2i52216!3i33905!1m4!1m3!1i16!2i52216!3i33906!2m3!1e0!2sm!3i274286854!3m9!2sen-US!3sUS!5e18!12m1!1e47!12m3!1e37!2m1!1ssmartmaps!4e3!20m1!1b1&callback=_xdc_._tqk0yl&token=74605"></script>
<body>    
    <div itemscope itemtype="http://schema.org/LocalBusiness" class="container">
        <div class="row">
            <div class="col-xs-3 col-md-3">
                <img src="<?php echo base_url(); ?>images/logo4.png" alt="K-Link Logo">            
            </div>
            <div class="col-xs-8 col-md-8">
                <div class="row">
                    <div class="col-xs-8 col-md-8">
                        <p class="text-info"> </p>
                    </div>
                    <div class="col-xs-8 col-md-8 pull-right">
                        <p class="text-info"><a href="<?php echo site_url() . '/store'; ?>"><i class="fa fa-shopping-cart"></i> Web Store </a>|<?php echo anchor('http://k-cashonline.com', 'Service'); ?> | <a href="<?php echo site_url() . '/blog'; ?>">Blog </a> | <a href="<?php echo site_url() . '/contact'; ?>">Contact us </a> | <?php echo anchor('http://www.k-link.co.id/community/', 'Community'); ?> | <a href="<?php echo site_url() . '/stockist'; ?>">Locate Stockist</a> | <?php echo anchor('https://www.k-linkindo.com/', 'Distributor Login'); ?> | <a href="<?php echo site_url() . '/career'; ?>">Career |</a><a class="" href="<?php echo site_url() . '/rss_feeds'; ?>">RSS <i class="fa fa-rss"></i> </a></p>
                    </div>
                    <div class="col-xs-8 col-md-8 pull-right">
                        <form class="form-inline" role="form">
                            <div class="form-group">
                                <label class="sr-only" for="search-articel">Look for..</label>
                                <input type="email" class="form-control" id="search-articel" placeholder="Articel / Item">
                                <button type="button" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>    
                </div>
            </div>
        </div>  
        <!-- <br>  -->     
        <nav class="navbar navbar-default" role="navigation">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>              
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if (count($mHeader) > 0):
                            foreach ($mHeader->result() as $hMenu):

                                if ($hMenu->menu_url == null):
                                    echo "<li>" . anchor($hMenu->menu_url, $hMenu->menu_title) . "\n";
                                else:
                                    echo "<li class='dropdown'>" . "\n";
                                    echo "<a class='dropdown-toggle' data-toggle='dropdown' href=" . site_url() . "/" . $hMenu->menu_url . ">" . $hMenu->menu_title . "<b class=\"caret\"></b> </a>" . "\n";
                                endif;

                                if (count($mChild) > 0):
                                    echo "<ul class='dropdown-menu'>" . "\n";
                                    foreach ($mChild->result() as $cMenu):
                                        if ($hMenu->menu_category == $cMenu->menu_category):
                                            echo "<li>" . anchor($cMenu->menu_url, $cMenu->menu_title) . "</li>" . "\n";
                                        endif;
                                    endforeach;
                                    echo "</ul>" . "\n";
                                endif;

                                echo "</li>" . "\n";
                            endforeach;
                        endif;
                        ?> 
                    </ul>             
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>

        <div class="row">
            <div class="row">
                <div class="col-xs-12 col-md-12">
                    <div class="page-header">
                        <h1><i class="fa fa-globe"></i> Contact Us</h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-md-12">
                    <img src="<?php echo base_url() . '/images/contact.jpg'; ?>" class="img-responsive" alt="Contact us">
                </div>
            </div>
            <div class="row">      
                <div class="col-xs-3 col-md-3">
                    <br>
                    <address>
                        <img itemprop="image" class="img-icon img-circle img-responsive" src="http://www.k-link.co.id/images/ngedung.jpg" alt="Responsive image"/>
                        <h4>PT. K-LINK</h4>          
                        <address>K-LINK TOWER
                            <span itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
                                <span itemprop="streetAddress">, JL.Gatot Subroto Kav. 59 A</span>, 
                                <span itemprop="addressLocality">Jakarta Selatan</span> 
                                <span itemprop="postalCode">12950</span> - 
                                <span itemprop="addressCountry">Indonesia</span>
                            </span><ul class="address">
                                <li><span class="glyphicon glyphicon-earphone"></span> Tel. 
                                    <span itemprop="telephone">021.290.27.000</span></li>
                                <li><span class="glyphicon glyphicon-phone-alt"></span> Fax. 021.290.27.001 - 290.27.004 </li>            
                            </ul>
                            <p>Business Hour</p>
                            <ul class="address">            
                                <li><span class="glyphicon glyphicon-time"></span> Monday - Friday : 10:00AM until 18:00PM</li>
                                <li><span class="glyphicon glyphicon-time"></span> Saturday : 10:00AM until 14:00PM</li>
                                <li><span class="glyphicon glyphicon-time"></span> Sunday We Are Close</li>
                            </ul> 
                        </address>
                    </address></div>
                <div class="col-xs-8 col-md-8">
                    <br>
                    <div id="map-location" class="map-style">
                    </div>
                </div>
            </div>  
           