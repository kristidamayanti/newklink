 <div class="row">     
        <div class="col-xs-12 col-md-12">
            <hr class="featurette-divider">
            <div class="col-xs-12 col-md-4">
                <h3>Sign up to our e-mail </h3>
                <form action="//k-link.us9.list-manage.com/subscribe/post?u=47314fe9f13048a3b7ae50701&amp;id=98e8200075" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate form-inline" target="_blank" novalidate>                        
                    <div class="form-group">
                        <input class="form-control" type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="email address" required >
                        <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                    </div>
                    <div class="form-group">
                        <div style="position: absolute; left: -5000px;"><input type="text" name="b_47314fe9f13048a3b7ae50701_98e8200075" class="form-control" tabindex="-1" value=""></div>
                        <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="btn btn-primary"></div>
                    </div>
                </form>
            </div>
            <div class="col-xs-12 col-md-4">
                <ul class="list-unstyled list-inline"> 
                	 <!--<li><a href="http://www.cepamagz.com"><img src="<?php echo base_url() . 'images/logo_cepa.png' ?>" alt="Logo Cepa Magz" ></a></li> -->
                </ul>                   
            
            </div>
            <div class="col-xs-12 col-md-4" style="text-align:right;">
                <h3>Get Social, Follow us on </h3>
                <ul class="list-unstyled list-inline" style="text-align:right;">                    
                    <li><?php echo anchor('https://www.facebook.com/pages/AP-K-Link-Indonesia/154582434691756', '<i class="fa fa-2x fa-facebook-square text-info"></i>'); ?></li>
                    <li><?php echo anchor('https://twitter.com/official_klink', '<i class="fa fa-2x fa-twitter-square text-primary"></i>'); ?></li>
                    <li><?php echo anchor('http://www.youtube.com/channel/UC1YLBuEkJLzocmc_yp5Pgvw', '<i class="fa fa-2x fa-youtube-square text-danger"></i>'); ?></li>
                    <li><?php echo anchor('http://instagram.com/klink_indonesia_official?ref=badge', '<i class="fa fa-2x fa-instagram text-primary"></i>'); ?></li>
                    <li><script src="//platform.linkedin.com/in.js" type="text/javascript">
                        lang: in_ID
                        </script>
                        <script type="IN/FollowCompany" data-id="3876026" data-counter="none"></script></li> 
                    <li><div class="g-follow" data-href="https://plus.google.com/115183062087900017478" data-annotation="none" data-height="20"></div></li>                       
                </ul> 
            </div>            
        </div>
        <div style="border: 0; clear: both;height: 1px;max-width: 1140px;margin: 0 auto;padding-top: 20px;margin-bottom: 20px;;border-bottom: 1px solid #3f8d35;"></div>
        <br>        
        <div class="col-xs-12 col-md-12">
            <div class="col-xs-12 col-md-3">
            	<h4>Tentang K-Link</h4>
                <hr class="featurette-divider" style="border-color:#999;">
                <p><a href="<?php echo site_url() . '/aboutus'; ?>">About Us</a></p>
                <p><a href="<?php echo site_url() . '/profile'; ?>">Company Profile </a></p>
                <p><a href="<?php echo site_url() . '/bod'; ?>">Board Of Director </a></p>
                <p><a href="<?php echo site_url() . '/presdir'; ?>">President Director </a></p>
                <p><a href="<?php echo site_url() . '/gm'; ?>">General Manager </a></p>
                <p><a href="<?php echo site_url() . '/visimisi'; ?>">Vision and Mission </a></p>
                <p><a href="<?php echo site_url() . '/csr'; ?>">CSR K-Link Care </a></p>
            </div>
            <div class="col-xs-12 col-md-3">
                <h4>Bussiness Oppurtunity</h4>
                <hr class="featurette-divider" style="border-color:#999;">
                <p><a href="<?php echo site_url() . 'directselling'; ?>">What is Direct Selling?</a></p>
                <p><a href="<?php echo site_url() . 'why'; ?>">Why Choose K-Link?</a></p>
                <p><a href="<?php echo site_url() . 'rca'; ?>">Our Royal Crown Ambassadors </a></p>
                <p><a href="<?php echo site_url() . 'successstories'; ?>">Success Stories </a></p>
                <p><a href="<?php echo site_url() . 'howdo'; ?>">How Do I Join?</a></p>
                <p><a href="<?php echo site_url() . 'marketingplan'; ?>">Our Marketing Plan </a></p>
                <p><a href="<?php echo site_url() . 'around'; ?>">Around The World </a></p>
            </div>
            <div class="col-xs-12 col-md-2">
            	<h4>Helpful Links</h4>
                <hr class="featurette-divider" style="border-color:#999;">
                <p><a href="<?php echo site_url() . 'blog'; ?>">Blog</a></p>
                <p><a href="<?php echo site_url() . 'career'; ?>">Career </a></p>
                <p><a href="http://k-cashonline.com/">Services </a></p>
                <p><a href="<?php echo site_url() . 'store'; ?>">Web Store </a></p>
                <p><a href="<?php echo site_url() . 'community'; ?>">Community</a></p>
                <p><a href="<?php echo site_url() . 'stockist'; ?>">Locate Stockist</a></p>
                <p><a href="https://www.k-linkindo.com/member/index.jsp">Distributor Login</a></p>
                <p><a href="http://www.k-link.co.id/news/det/73/Harga-K-Link-terbaru-Per-Juli-2014">Price List</a></p>
            </div>
            <div class="col-xs-12 col-md-4">
                
                <!-- <h2>Address</h2> -->
            <address>
                <div style="float:left; width:25%;"><img class="img-icon img-circle img-responsive" style="max-width:80%;" src="<?php echo base_url(); ?>images/ngedung.jpg" alt="Responsive image"></div>
                <div style="float:left; width:75%;">
                <h4>PT. K-LINK</h4>          
                <address>K-LINK TOWER, JL.Gatot Subroto Kav. 59 A, Jakarta Selatan 12950 - Indonesia</address>
               
                </div>                
                <div>
                	<ul class="address" style="padding-left:10px;">
                        <li><span class="glyphicon glyphicon-earphone"></span> Tel. 021.290.27.000</li>
                        <li><span class="glyphicon glyphicon-phone-alt"></span> Fax. 021.290.27.001 - 290.27.004 </li>
                        <li><span class="glyphicon glyphicon-time"></span> Monday - Friday : 10:00AM until 18:00PM</li>
                        <li><span class="glyphicon glyphicon-time"></span> Saturday : 10:00AM until 14:00PM</li>
                        <li><span class="glyphicon glyphicon-envelope"></span> customer_service[at]k-link.co.id</li>
                    </ul>
                </div>
                <p>Download Mobile Aplication K-TV Channel di sini</p>
                <ul class="list-unstyled list-inline">                                        
                    <li>
                        <a href="https://play.google.com/store/apps/details?id=com.phonegap.klink">
                            <img alt="Get it on Google Play"
                                 src="https://developer.android.com/images/brand/en_generic_rgb_wo_45.png" />
                        </a>
                    </li>
                </ul>
            </div>          
        </div>

    </div> <!-- rows -->    
    <?php
    if (isset($nilai)):
        $total = $nilai->count;
    endif;
    ?>    
    <footer>
        <p style="text-align: center;" >Copyright &copy;2014 -  PT K-Link Indonesia - <?php echo anchor('/syariah', 'MLM Bersistem Syariah') ?> -<?php echo anchor('/disclaimer', 'Disclaimer') ?> - <?php echo anchor('http://www.apli.co.id', 'APLI Register No:0069/04/03'); ?></p>
    </footer>
</div> <!-- /container -->

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?php echo base_url(); ?>js/asyncLoader.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.easyPaginate.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.popup.min.js"></script>
<script src="https://apis.google.com/js/platform.js" async defer></script>
<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script src="<?php echo base_url(); ?>js/comment.js"></script>
<script src="<?php echo base_url(); ?>js/holder.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.sharrre.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.gmap.min.js"></script>
<script>
						$('#sosmed').sharrre({
							share: {
								googlePlus: true,
								facebook: true,
								twitter: true,
								linkedin: true,
								pinterest: true
							},
							buttons: {
								googlePlus: {size: 'tall', annotation: 'bubble'},
								facebook: {layout: 'box_count'},
								twitter: {count: 'vertical', via: '_JulienH'}
							},
							hover: function(api, options) {
								$(api.element).find('.buttons').show();
							},
							hide: function(api, options) {
								$(api.element).find('.buttons').hide();
							},
							enableTracking: true
						});
</script>

<script>
        $(document).ready(function() {
            function reset() {
                $("#toggleCSS").attr("href", "<?php echo base_url(); ?>css/alertify.css");
                alertify.set({
                    labels: {
                        ok: "OK",
                        cancel: "Cancel"
                    },
                    delay: 5000,
                    buttonReverse: false,
                    buttonFocus: "ok"
                });
            }


            $('#testimony').click(function() {
                reset();
                alertify.alert("Thank You For Your Testimonial ");
                alertify.success("Post Successfull !");
            });

        });
    </script>

<script>
                        asyncLoader(
                                [
                                    '<?php echo base_url(); ?>css/bootstrap.css',
                                    '<?php echo base_url(); ?>css/magic-bootstrap.css',
                                    '<?php echo base_url(); ?>css/style.css',
                                    '<?php echo base_url(); ?>css/alertify.css',
                                    '<?php echo base_url(); ?>css/fwa/css/font-awesome.css',
                                    '<?php echo base_url(); ?>css/lightbox.css',
                                    '<?php echo base_url(); ?>js/bootstrap.min.js',
                                    '<?php echo base_url(); ?>css/popup.css'
                                ],
                                {
                                    'callback': function() {
                                        $('body').fadeIn(500);
                                        $('#carousel-example-generic').delay(800).fadeIn();
                                    }
                                }
                        );
</script>
<script>
    $('#productpaging').easyPaginate({
        paginateElement: 'li',
        elementsPerPage: 3,
        nextButton: false,
        prevButton: false,
        firstButtonText: '<i class="fa text-primary fa-2x fa-arrow-circle-left"></i>',
        lastButtonText: '<i class="fa text-primary fa-2x fa-arrow-circle-right"></i>'
    });
</script>
<script>
//    $(document).ready(function() {
//        var popup = new $.Popup();
//
//        popup.open('<?php echo base_url(); ?>images/rave_burger_5.jpg');
//
//        setTimeout(function() {
//            popup.close();
//        }, 8000);
//    });
</script>
<script>
    (function(i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function() {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-54221164-1', 'auto');
    ga('send', 'pageview');

</script>

<script>
                            $('#map-location').gMap({
                                maptype: 'ROADMAP',
                                scrollwheel: false,
                                zoom: 16,
                                markers: [
                                    {
                                        address: 'Gedung Tower K - Link, Tower K - Link, Jalan Jenderal Gatot Subroto, Kota Jakarta Selatan, DKI Jakarta', // Your Adress Here
                                        html: '',
                                        latitude: '-6.2402160',
                                        longitude: '106.8344060',
                                        popup: true,
                                    }
                                ],
                            });
    </script>

</body>
</html>

<!-- NAVBAR
==

