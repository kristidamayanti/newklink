<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<body>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-3">
                <img src="<?php echo base_url(); ?>images/logo4.png" alt="K-Link Logo" height="105" width="260px" >            
            </div>
            <div class="col-xs-12 col-md-8">
                <div class="row">                    
                    <div class="col-xs-12 col-md-8 pull-right">
                        <p class="text-info"><a href="<?php echo site_url() . '/store'; ?>"><i class="fa fa-shopping-cart"></i> Web Store </a>|<?php echo anchor('http://k-cashonline.com', 'Service'); ?> | <a href="<?php echo site_url() . 'blog'; ?>">Blog </a> | <a href="<?php echo site_url() . 'contact'; ?>">Contact us </a> | <?php echo anchor('http://www.k-link.co.id/community/', 'Community'); ?> | <a href="<?php echo site_url() . 'stockist'; ?>">Locate Stockist</a> | <?php echo anchor('https://www.k-linkindo.com/', 'Distributor Login'); ?> | <a href="<?php echo site_url() . 'career'; ?>">Career |</a><a class="" href="<?php echo site_url() . 'rss_feeds'; ?>">RSS <i class="fa fa-rss"></i> </a></p>
                    </div>
                    <div class="col-xs-12 col-md-8 pull-right">
                        <form class="form-inline" role="form">
                            <div class="form-group">
                                <label class="sr-only" for="search-articel">Look for..</label>
                                <input type="email" class="form-control" id="search-articel" placeholder="Articel / Item">
                                <button type="button" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>    
                </div>
            </div>
        </div>   
        <!-- <br>  -->     
        <nav class="navbar navbar-default" role="navigation">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>              
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <?php
                        if (count($mHeader) > 0):
                            foreach ($mHeader->result() as $hMenu):

                                if ($hMenu->menu_url == null):
                                    echo "<li>" . anchor($hMenu->menu_url, $hMenu->menu_title) . "\n";
                                else:
                                    echo "<li class='dropdown'>" . "\n";
                                    echo "<a class='dropdown-toggle' data-toggle='dropdown' href=" . site_url() . "/" . $hMenu->menu_url . ">" . $hMenu->menu_title . "<b class=\"caret\"></b> </a>" . "\n";
                                endif;

                                if (count($mChild) > 0):
                                    echo "<ul class='dropdown-menu'>" . "\n";
                                    foreach ($mChild->result() as $cMenu):
                                        if ($hMenu->menu_category == $cMenu->menu_category):
                                            echo "<li>" . anchor($cMenu->menu_url, $cMenu->menu_title) . "</li>" . "\n";
                                        endif;
                                    endforeach;
                                    echo "</ul>" . "\n";
                                endif;

                                echo "</li>" . "\n";
                            endforeach;
                        endif;
                        ?> 
                    </ul>             
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>

        <div class="row">
            <div class="col-xs-12 col-md-12">
                <div class="page-header">
                    <h1><i class="fa fa-coffee fa-2x text-primary"></i> K-Link Blog</h1>
                </div>
            </div>

            <div class="col-xs-12 col-md-12">
                <br>
                <div class="col-xs-12 col-md-3">
                    <div class="thumbnail">                        
                        <H3 class="text-center text-info">Success Stories</H3>
                        <hr class="box">
                        <?php
                        if (count($stories) > 0):
                            foreach ($stories as $rowStories) {
                                $imgprop = array(
                                    'src' => 'upload/blog/thumbnail/' . $rowStories->bl_profilepict,
                                    'alt' => $rowStories->bl_name,
                                    'class' => 'img-responsive',
                                    'width' => '147',
                                    'height' => '110',
                                );

                                echo '<a href =' . site_url() . '/successstories/det/' . $rowStories->id . '/' . url_title($rowStories->bl_title).'>'. img($imgprop) . '</a>';
                                echo "<p class = text-center><a href =" . site_url() . '/successstories/det/' . $rowStories->id . '/' . url_title($rowStories->bl_title) . " class=\"text-info\">$rowStories->bl_title</a>" . br(2);
                            }
                        endif;
                        ?>                        
                    </div>
                    <br>
                    <div class="list-group">
                        <a href="#" class="list-group-item list-group-item-info">
                            <H3>Blog Archive</H3>
                        </a>
                        <?php
                        if (count($gYear) > 0):
                            foreach ($gYear as $row) {
                                echo "<a href=\"#\" class=\"list-group-item\">$row->grpyear</a>";
                            }
                        endif;
                        ?>                        
                    </div>                    
                </div>
                <div class="col-xs-12 col-md-9">
                    <br>
                    <?php
                    if (count($allBlog) > 0):
                        foreach ($allBlog as $row):
                            ?>
                            <div class="row">
                                <div class="col-xs-3 col-md-2">
                                    <span class="fa-stack fa-3x">
                                        <i class="fa fa-calendar-o fa-stack-2x"></i>
                                        <strong class="fa-stack-1x calendar-text"><?php echo date('d', strtotime($row->createdt)); ?></strong>
                                    </span>
                                </div>                                   
                                <div class="col-xs-9 col-md-9">                  
                                    <h2><?php
                                        if (isset($row->bl_title)):
                                            echo $row->bl_title . ' - <small>' . $row->bl_name;
                                        endif;
                                        ?></small></h2>
                                    <p>  <?php
                                        if (isset($row->bl_content)):
                                            echo word_limiter($row->bl_content, 20);
                                        endif;
                                        ?> </p>  <a href="<?php echo site_url() . '/blog/det/' . $row->id . '/' . url_title($row->bl_title) ?>" class="text-primary"> Read More..</a>  
                                </div>                
                            </div> 
                            <hr class="featurette-divider">
                            <?php
                        endforeach;
                        echo "<div class=\"pager pull-right\">" . $halaman . "</div>";
                    endif;
                    ?>
                </div>

            </div>
